/*****************************************************************//**
 * @file main_vanilla_test.cpp
 *
 * @brief Basic test of 4 basic i/o cores
 *
 * @author p chu
 * @version v1.0: initial release
 *********************************************************************/

//#define _DEBUG
#include "chu_init.h"
#include "gpio_cores.h"

GpiCore sw(get_slot_addr(BRIDGE_BASE, S3_SW));
PwmCore  pwm(get_slot_addr(BRIDGE_BASE, S6_PWM));


int sw_check(GpiCore *sw_p) {
	int s1, s0;
	int result;

	s0 = sw_p->read(0);
	s1 = sw_p->read(1);

	switch (s0)
	{
	case 0:
		if (s1)
			result = 3;
		else
			result = 1;
		break;
	case 1:
		if (s1)
			result = 4;
		else
			result = 2;
		break;
	default:
		result = 1;
	}// switch (s0)

	return result;


} // sw_check



/**
 * Tricolor Led
 * @param sw_p pointer to switch instance
 */
void nightlight(PwmCore *Triled_p, GpiCore *sw_p) {
	double brightness = 1.0;
	double duty_cycle;
	double P20 = 1.2589;
	double max;
	const int time = 120;
	int spectrum_section;

	Triled_p -> set_freq(50);

	for (int i = 0; i < time; i++)
	{
		spectrum_section = i / 20;
		max = sw_check(sw_p) * 0.25;
		switch (spectrum_section)
		{
		case 0:
			// do stuff
			brightness = brightness * P20;
			duty_cycle = brightness / 100.0;
			//red
			Triled_p->set_duty(1.0 * max, 0);
			Triled_p->set_duty(1.0 * max, 3);
			//green
			Triled_p->set_duty(duty_cycle * max, 1);
			Triled_p->set_duty(duty_cycle * max, 4);
			//blue
			Triled_p->set_duty(0, 2);
			Triled_p->set_duty(0, 5);

			sleep_ms(100);
			break;
		case 1:
			// do stuff
			brightness = brightness * P20;
			duty_cycle = brightness / 100.0;
			//red
			Triled_p->set_duty(duty_cycle * max, 0);
			Triled_p->set_duty(duty_cycle * max, 3);
			//green
			Triled_p->set_duty(1.0 * max, 1);
			Triled_p->set_duty(1.0 * max, 4);
			//blue
			Triled_p->set_duty(0, 2);
			Triled_p->set_duty(0, 5);

			sleep_ms(100);
			break;

		case 2:
			// do stuff
			brightness = brightness * P20;
			duty_cycle = brightness / 100.0;
			//red
			Triled_p->set_duty(0, 0);
			Triled_p->set_duty(0, 3);
			//green
			Triled_p->set_duty(1.0 * max, 1);
			Triled_p->set_duty(1.0 * max, 4);
			//blue
			Triled_p->set_duty(duty_cycle * max, 2);
			Triled_p->set_duty(duty_cycle * max, 5);

			sleep_ms(100);
			break;
		case 3:
			// do stuff
			brightness = brightness * P20;
			duty_cycle = brightness / 100.0;
			//red
			Triled_p->set_duty(0, 0);
			Triled_p->set_duty(0, 3);
			//green
			Triled_p->set_duty(duty_cycle * max, 1);
			Triled_p->set_duty(duty_cycle * max, 4);
			//blue
			Triled_p->set_duty(1.0 * max, 2);
			Triled_p->set_duty(1.0 * max, 5);

			sleep_ms(100);
			break;
		case 4:
			// do stuff
			brightness = brightness * P20;
			duty_cycle = brightness / 100.0;
			//red
			Triled_p->set_duty(duty_cycle * max, 0);
			Triled_p->set_duty(duty_cycle * max, 3);
			//green
			Triled_p->set_duty(0, 1);
			Triled_p->set_duty(0, 4);
			//blue
			Triled_p->set_duty(1.0 * max, 2);
			Triled_p->set_duty(1.0 * max, 5);

			sleep_ms(100);
			break;
		case 5:
			// do stuff
			brightness = brightness * P20;
			duty_cycle = brightness / 100.0;
			//red
			Triled_p->set_duty(1.0 * max, 0);
			Triled_p->set_duty(1.0 * max, 3);
			//green
			Triled_p->set_duty(0, 1);
			Triled_p->set_duty(0, 4);
			//blue
			Triled_p->set_duty(duty_cycle * max, 2);
			Triled_p->set_duty(duty_cycle * max, 5);

			sleep_ms(100);
			break;
		default:
			uart.disp("DEFAULT: ERROR OCCURED\r\n");
		}// switch


	} //for



}// nightlight


/**
 * uart transmits test line.
 * @note uart instance is declared as global variable in chu_io_basic.h
 */
void uart_check() {
	static int loop = 0;

	uart.disp("Spectrum Cycle #");
	uart.disp(loop);
	uart.disp("\n\r");
	loop++;
}


int main() {

	while (1) {
		nightlight(&pwm, &sw);
		uart_check();
	} //while
} //main

